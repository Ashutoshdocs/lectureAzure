#!/usr/bin/env bash
# Deletes everything. Azure Firewall bills per hour, so run this when you're done.
set -euo pipefail
source "$(dirname "$0")/config.env"
read -r -p "Delete resource group '$RG' and everything in it? [y/N] " ans
[[ "$ans" =~ ^[Yy]$ ]] && az group delete -n "$RG" --yes --no-wait && echo "Deletion started."
