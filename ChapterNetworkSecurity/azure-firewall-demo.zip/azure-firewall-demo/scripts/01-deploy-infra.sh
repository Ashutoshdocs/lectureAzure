#!/usr/bin/env bash
# Step 1: Resource group, VNet + subnets, 2 Linux VMs (no public IPs), Azure Firewall, route tables.
set -euo pipefail
source "$(dirname "$0")/config.env"

echo ">>> Resource group"
az group create -n "$RG" -l "$LOCATION" -o none

echo ">>> VNet and subnets"
az network vnet create -g "$RG" -n "$VNET" \
  --address-prefixes "$VNET_CIDR" \
  --subnet-name AzureFirewallSubnet --subnet-prefixes "$FW_SUBNET_CIDR" -o none
az network vnet subnet create -g "$RG" --vnet-name "$VNET" -n "$FRONTEND_SUBNET" \
  --address-prefixes "$FRONTEND_SUBNET_CIDR" -o none
az network vnet subnet create -g "$RG" --vnet-name "$VNET" -n "$DB_SUBNET" \
  --address-prefixes "$DB_SUBNET_CIDR" -o none

echo ">>> Frontend VM (private only)"
az vm create -g "$RG" -n "$FRONTEND_VM" --image "$VM_IMAGE" --size "$VM_SIZE" \
  --vnet-name "$VNET" --subnet "$FRONTEND_SUBNET" --private-ip-address "$FRONTEND_IP" \
  --public-ip-address "" --nsg "" \
  --admin-username "$ADMIN_USER" --generate-ssh-keys -o none

echo ">>> MySQL VM (private only)"
az vm create -g "$RG" -n "$DB_VM" --image "$VM_IMAGE" --size "$VM_SIZE" \
  --vnet-name "$VNET" --subnet "$DB_SUBNET" --private-ip-address "$DB_IP" \
  --public-ip-address "" --nsg "" \
  --admin-username "$ADMIN_USER" --generate-ssh-keys -o none

echo ">>> Firewall public IP, policy and firewall (takes ~10 min)"
az extension add --name azure-firewall --upgrade -o none 2>/dev/null || true
az network public-ip create -g "$RG" -n "$FW_PIP" --sku Standard --allocation-method Static -o none
az network firewall policy create -g "$RG" -n "$FW_POLICY" --sku Standard -o none
az network firewall create -g "$RG" -n "$FW_NAME" -l "$LOCATION" \
  --sku AZFW_VNet --tier Standard --firewall-policy "$FW_POLICY" -o none
az network firewall ip-config create -g "$RG" -f "$FW_NAME" -n fw-ipconfig \
  --public-ip-address "$FW_PIP" --vnet-name "$VNET" -o none
az network firewall update -g "$RG" -n "$FW_NAME" -o none

FW_PRIVATE_IP=$(az network firewall show -g "$RG" -n "$FW_NAME" \
  --query "ipConfigurations[0].privateIPAddress" -o tsv)
FW_PUBLIC_IP=$(az network public-ip show -g "$RG" -n "$FW_PIP" --query ipAddress -o tsv)

echo ">>> Route tables: force all traffic (internet + subnet-to-subnet) through the firewall"
# Frontend subnet
az network route-table create -g "$RG" -n rt-frontend --disable-bgp-route-propagation true -o none
az network route-table route create -g "$RG" --route-table-name rt-frontend -n default-via-fw \
  --address-prefix 0.0.0.0/0 --next-hop-type VirtualAppliance --next-hop-ip-address "$FW_PRIVATE_IP" -o none
az network route-table route create -g "$RG" --route-table-name rt-frontend -n to-db-via-fw \
  --address-prefix "$DB_SUBNET_CIDR" --next-hop-type VirtualAppliance --next-hop-ip-address "$FW_PRIVATE_IP" -o none
az network vnet subnet update -g "$RG" --vnet-name "$VNET" -n "$FRONTEND_SUBNET" --route-table rt-frontend -o none

# DB subnet
az network route-table create -g "$RG" -n rt-db --disable-bgp-route-propagation true -o none
az network route-table route create -g "$RG" --route-table-name rt-db -n default-via-fw \
  --address-prefix 0.0.0.0/0 --next-hop-type VirtualAppliance --next-hop-ip-address "$FW_PRIVATE_IP" -o none
az network route-table route create -g "$RG" --route-table-name rt-db -n to-frontend-via-fw \
  --address-prefix "$FRONTEND_SUBNET_CIDR" --next-hop-type VirtualAppliance --next-hop-ip-address "$FW_PRIVATE_IP" -o none
az network vnet subnet update -g "$RG" --vnet-name "$VNET" -n "$DB_SUBNET" --route-table rt-db -o none

cat <<EOF

=====================================================
 Infrastructure ready
 Firewall private IP : $FW_PRIVATE_IP
 Firewall public IP  : $FW_PUBLIC_IP
 Next: ./02-firewall-rules.sh
=====================================================
EOF
