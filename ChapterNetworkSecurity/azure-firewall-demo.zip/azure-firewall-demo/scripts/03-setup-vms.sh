#!/usr/bin/env bash
# Step 3: Copy setup files to both VMs through the firewall DNAT SSH ports and run them.
set -euo pipefail
source "$(dirname "$0")/config.env"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FW_PUBLIC_IP=$(az network public-ip show -g "$RG" -n "$FW_PIP" --query ipAddress -o tsv)
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

echo ">>> MySQL VM via $FW_PUBLIC_IP:$DNAT_SSH_DB_PORT"
scp $SSH_OPTS -P "$DNAT_SSH_DB_PORT" "$ROOT/backend/setup-mysql.sh" "$ADMIN_USER@$FW_PUBLIC_IP:/tmp/"
ssh $SSH_OPTS -p "$DNAT_SSH_DB_PORT" "$ADMIN_USER@$FW_PUBLIC_IP" \
  "sudo FRONTEND_SUBNET_PATTERN='10.0.2.%' bash /tmp/setup-mysql.sh"

echo ">>> Frontend VM via $FW_PUBLIC_IP:$DNAT_SSH_FE_PORT"
scp $SSH_OPTS -r -P "$DNAT_SSH_FE_PORT" "$ROOT/frontend" "$ADMIN_USER@$FW_PUBLIC_IP:/tmp/"
ssh $SSH_OPTS -p "$DNAT_SSH_FE_PORT" "$ADMIN_USER@$FW_PUBLIC_IP" \
  "sudo DB_HOST='$DB_IP' bash /tmp/frontend/setup-frontend.sh"

echo ""
echo "Open in your browser:  http://$FW_PUBLIC_IP"
