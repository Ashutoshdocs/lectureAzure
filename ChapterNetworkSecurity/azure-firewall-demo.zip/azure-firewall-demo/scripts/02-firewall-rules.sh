#!/usr/bin/env bash
# Step 2: Firewall Policy rules
#   - DNAT rules   : reach the VMs through the firewall public IP
#   - Network rule : frontend VM -> MySQL VM on TCP 3306 only
#   - App rules    : VMs may browse Google, YouTube is explicitly denied
set -euo pipefail
source "$(dirname "$0")/config.env"

FW_PUBLIC_IP=$(az network public-ip show -g "$RG" -n "$FW_PIP" --query ipAddress -o tsv)
echo "Firewall public IP: $FW_PUBLIC_IP   |   SSH allowed from: $MY_IP"

# --------------------------------------------------------------------
# 1) DNAT rule collection group
# --------------------------------------------------------------------
az network firewall policy rule-collection-group create -g "$RG" \
  --policy-name "$FW_POLICY" -n rcg-dnat --priority 100 -o none

# Web: anyone -> FW_PUBLIC_IP:80 -> frontend:80
az network firewall policy rule-collection-group collection add-nat-collection -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-dnat -n dnat-inbound --collection-priority 100 \
  --action DNAT --rule-name web-to-frontend --ip-protocols TCP \
  --source-addresses "*" --destination-addresses "$FW_PUBLIC_IP" --destination-ports "$DNAT_HTTP_PORT" \
  --translated-address "$FRONTEND_IP" --translated-port 80 -o none

# SSH to frontend: MY_IP -> FW_PUBLIC_IP:2201 -> frontend:22
az network firewall policy rule-collection-group collection rule add -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-dnat --collection-name dnat-inbound \
  -n ssh-to-frontend --rule-type NatRule --ip-protocols TCP \
  --source-addresses "$MY_IP" --destination-addresses "$FW_PUBLIC_IP" --destination-ports "$DNAT_SSH_FE_PORT" \
  --translated-address "$FRONTEND_IP" --translated-port 22 -o none

# SSH to MySQL VM: MY_IP -> FW_PUBLIC_IP:2202 -> mysql:22
az network firewall policy rule-collection-group collection rule add -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-dnat --collection-name dnat-inbound \
  -n ssh-to-mysql --rule-type NatRule --ip-protocols TCP \
  --source-addresses "$MY_IP" --destination-addresses "$FW_PUBLIC_IP" --destination-ports "$DNAT_SSH_DB_PORT" \
  --translated-address "$DB_IP" --translated-port 22 -o none

# --------------------------------------------------------------------
# 2) Network rule collection group
# --------------------------------------------------------------------
az network firewall policy rule-collection-group create -g "$RG" \
  --policy-name "$FW_POLICY" -n rcg-network --priority 200 -o none

az network firewall policy rule-collection-group collection add-filter-collection -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-network -n allow-app-to-db --collection-priority 100 \
  --action Allow --rule-type NetworkRule --rule-name frontend-to-mysql-3306 \
  --ip-protocols TCP --source-addresses "$FRONTEND_IP" \
  --destination-addresses "$DB_IP" --destination-ports 3306 -o none

# --------------------------------------------------------------------
# 3) Application rule collection group
#    Lower priority number = evaluated first, so the Deny runs before the Allow.
# --------------------------------------------------------------------
az network firewall policy rule-collection-group create -g "$RG" \
  --policy-name "$FW_POLICY" -n rcg-application --priority 300 -o none

# 3a) DENY YouTube (priority 100)
az network firewall policy rule-collection-group collection add-filter-collection -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-application -n deny-youtube --collection-priority 100 \
  --action Deny --rule-type ApplicationRule --rule-name block-youtube \
  --protocols Http=80 Https=443 \
  --source-addresses "$FRONTEND_SUBNET_CIDR" "$DB_SUBNET_CIDR" \
  --target-fqdns "youtube.com" "*.youtube.com" "youtu.be" "*.ytimg.com" "*.googlevideo.com" -o none

# 3b) ALLOW Google (priority 200)
az network firewall policy rule-collection-group collection add-filter-collection -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-application -n allow-google --collection-priority 200 \
  --action Allow --rule-type ApplicationRule --rule-name allow-google \
  --protocols Http=80 Https=443 \
  --source-addresses "$FRONTEND_SUBNET_CIDR" "$DB_SUBNET_CIDR" \
  --target-fqdns "google.com" "*.google.com" "*.gstatic.com" -o none

# 3c) ALLOW Ubuntu package repos so the setup scripts can apt install (priority 300)
az network firewall policy rule-collection-group collection rule add -g "$RG" \
  --policy-name "$FW_POLICY" --rcg-name rcg-application --collection-name allow-google \
  -n allow-ubuntu-updates --rule-type ApplicationRule \
  --protocols Http=80 Https=443 \
  --source-addresses "$FRONTEND_SUBNET_CIDR" "$DB_SUBNET_CIDR" \
  --target-fqdns "*.ubuntu.com" "archive.ubuntu.com" "security.ubuntu.com" "*.launchpad.net" -o none

cat <<EOF

=====================================================
 Firewall rules applied
   Web app        : http://$FW_PUBLIC_IP
   SSH frontend   : ssh -p $DNAT_SSH_FE_PORT $ADMIN_USER@$FW_PUBLIC_IP
   SSH mysql vm   : ssh -p $DNAT_SSH_DB_PORT $ADMIN_USER@$FW_PUBLIC_IP
 Next: set up the VMs (see README step 4)
=====================================================
EOF
