#!/usr/bin/env bash
# Run on the MySQL VM (10.0.3.4) as root:  sudo bash setup-mysql.sh
set -euo pipefail

DB_NAME="${DB_NAME:-fwdemo}"
DB_USER="${DB_USER:-appuser}"
DB_PASS="${DB_PASS:-Demo@Pass123!}"
FRONTEND_SUBNET_PATTERN="${FRONTEND_SUBNET_PATTERN:-10.0.2.%}"   # hosts allowed to log in

export DEBIAN_FRONTEND=noninteractive
echo ">>> Installing MySQL (apt traffic goes out through Azure Firewall)"
apt-get update -y
apt-get install -y mysql-server

echo ">>> Listening on all interfaces (the firewall decides who can reach 3306)"
sed -i 's/^bind-address.*/bind-address = 0.0.0.0/' /etc/mysql/mysql.conf.d/mysqld.cnf
sed -i 's/^mysqlx-bind-address.*/mysqlx-bind-address = 127.0.0.1/' /etc/mysql/mysql.conf.d/mysqld.cnf
systemctl restart mysql
systemctl enable mysql

echo ">>> Database, user and sample data"
mysql <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;
CREATE USER IF NOT EXISTS '${DB_USER}'@'${FRONTEND_SUBNET_PATTERN}' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'${FRONTEND_SUBNET_PATTERN}';
FLUSH PRIVILEGES;

USE \`${DB_NAME}\`;
CREATE TABLE IF NOT EXISTS products (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100)  NOT NULL,
  category   VARCHAR(50)   NOT NULL,
  price      DECIMAL(10,2) NOT NULL,
  stock      INT           NOT NULL DEFAULT 0,
  created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

SQL

# Seed sample rows only on first run
if [ "$(mysql -N -e "SELECT COUNT(*) FROM \`${DB_NAME}\`.products")" = "0" ]; then
mysql "${DB_NAME}" <<'SQL'
INSERT INTO products (name, category, price, stock) VALUES
 ('Mechanical Keyboard',         'Peripherals', 4999.00, 25),
 ('Noise-Cancelling Headphones', 'Audio',      12999.00, 12),
 ('27 inch 4K Monitor',          'Displays',   28999.00,  8),
 ('USB-C Dock',                  'Accessories', 6499.00, 40);
SQL
fi

echo ""
echo "MySQL ready: db=${DB_NAME} user=${DB_USER} allowed from ${FRONTEND_SUBNET_PATTERN}"
