# 🛡️ Azure Firewall Demo — Frontend VM + MySQL VM

A hands-on lab that puts **two private Linux VMs** behind **Azure Firewall (Standard, with Firewall Policy)** and shows all three rule types working:

| Rule type | What it does in this lab |
|---|---|
| **DNAT** | `FirewallPublicIP:80` → frontend web app · `:2201` → SSH frontend VM · `:2202` → SSH MySQL VM |
| **Network** | Allows **only** `10.0.2.4 → 10.0.3.4 : TCP 3306` (frontend → MySQL) |
| **Application** | VMs **can** reach `*.google.com` · VMs **cannot** reach `*.youtube.com` |

The frontend is an interactive dashboard (Flask + MySQL) you open in your browser at `http://<FIREWALL_PUBLIC_IP>`. It shows the traffic path and lets you run live firewall tests and add, edit and delete inventory rows stored in MySQL.

---

## 1. Architecture

```
                      Internet
                         │
              http://<FW_PUBLIC_IP>  (also :2201 / :2202 SSH)
                         │
┌────────────────────────┼──────────────── vnet-azfw-demo 10.0.0.0/16 ─────────────┐
│                        ▼                                                          │
│   AzureFirewallSubnet 10.0.1.0/26      ┌───────────────────────────┐              │
│   ┌────────────────────────────┐       │  Firewall Policy          │              │
│   │  Azure Firewall  10.0.1.4  │◄──────┤  • rcg-dnat        (100)  │              │
│   └─────┬──────────────▲───────┘       │  • rcg-network     (200)  │              │
│   DNAT  │              │ UDR 0.0.0.0/0 │  • rcg-application (300)  │              │
│   :80   │              │ + cross-subnet└───────────────────────────┘              │
│         ▼              │                                                          │
│   snet-frontend 10.0.2.0/24            snet-db 10.0.3.0/24                        │
│   ┌──────────────────────┐   3306 via  ┌──────────────────────┐                   │
│   │ vm-frontend 10.0.2.4 │──firewall──►│ vm-mysql  10.0.3.4   │                   │
│   │ Flask + Gunicorn :80 │             │ MySQL 8  :3306       │                   │
│   └──────────────────────┘             └──────────────────────┘                   │
│     rt-frontend: 0.0.0.0/0 → FW          rt-db: 0.0.0.0/0 → FW                    │
│                  10.0.3.0/24 → FW               10.0.2.0/24 → FW                  │
└───────────────────────────────────────────────────────────────────────────────────┘
```

**Why two subnets?** Traffic between VMs in the *same* subnet never goes through the firewall. Putting the frontend and the database in separate subnets, with routes (UDRs) that send cross-subnet traffic to the firewall, is what makes the network rule enforce anything.

---

## 2. Project structure

```
azure-firewall-demo/
├── README.md
├── scripts/
│   ├── config.env              # names, IPs, ports — edit first
│   ├── 01-deploy-infra.sh      # RG, VNet, subnets, 2 VMs, Firewall, route tables
│   ├── 02-firewall-rules.sh    # DNAT + Network + Application rules
│   ├── 03-setup-vms.sh         # copies & runs the setup scripts through the firewall
│   └── 99-cleanup.sh           # deletes everything
├── backend/
│   └── setup-mysql.sh          # MySQL install, remote access, DB/user/table/seed data
└── frontend/
    ├── setup-frontend.sh       # installs Flask/PyMySQL/Gunicorn, systemd service
    ├── fwdemo.service          # systemd unit (gunicorn on :80)
    ├── app.py                  # Flask API + firewall test endpoints
    └── templates/index.html    # the UI
```

---

## 3. Prerequisites

- An Azure subscription (Azure Firewall Standard costs about **US$1.25/hour** plus data processing, so delete the lab when you finish).
- **Azure Cloud Shell (Bash)** or a local machine with Azure CLI 2.50+, `ssh`, `scp` and `curl`.
- `az login`, then `az account set -s <subscription-id>`.

> Cloud Shell's outbound IP changes between sessions. If SSH through the firewall stops working, re-run `02-firewall-rules.sh` (it updates `MY_IP`) or set `export MY_IP=<your-ip>` before running it.

---

## 4. Deploy: quick path (3 commands)

```bash
cd azure-firewall-demo/scripts
chmod +x *.sh ../backend/*.sh ../frontend/*.sh

./01-deploy-infra.sh      # ~10-15 min (the firewall takes the longest)
./02-firewall-rules.sh    # ~3-5 min
./03-setup-vms.sh         # ~3-5 min, installs MySQL + the web app
```

When it finishes it prints:

```
Open in your browser:  http://<FIREWALL_PUBLIC_IP>
```

---

## 5. Deploy: step by step (what each script does)

### Step 1: Network and VMs (`01-deploy-infra.sh`)
1. Resource group `rg-azfw-demo`.
2. VNet `10.0.0.0/16` with three subnets:
   - `AzureFirewallSubnet` `10.0.1.0/26` (the name is mandatory)
   - `snet-frontend` `10.0.2.0/24`
   - `snet-db` `10.0.3.0/24`
3. Two Ubuntu 22.04 VMs with static private IPs and **no public IP**:
   - `vm-frontend` → `10.0.2.4`
   - `vm-mysql` → `10.0.3.4`
4. A Standard public IP, a Firewall Policy (Standard) and Azure Firewall (Standard), attached to the VNet.
5. Route tables:
   - `rt-frontend`: `0.0.0.0/0 → FW` and `10.0.3.0/24 → FW`
   - `rt-db`: `0.0.0.0/0 → FW` and `10.0.2.0/24 → FW`

### Step 2: Firewall rules (`02-firewall-rules.sh`)

#### 🔁 DNAT rules (`rcg-dnat`, priority 100)
| Rule | Source | Destination | Port | Translated to |
|---|---|---|---|---|
| web-to-frontend | `*` | FW public IP | 80 | `10.0.2.4:80` |
| ssh-to-frontend | `MY_IP` | FW public IP | 2201 | `10.0.2.4:22` |
| ssh-to-mysql | `MY_IP` | FW public IP | 2202 | `10.0.3.4:22` |

A DNAT rule automatically adds an implicit network rule that allows the translated traffic, so you don't need a separate allow rule.

#### 🔌 Network rule (`rcg-network`, priority 200)
| Collection | Action | Source | Destination | Protocol/Port |
|---|---|---|---|---|
| allow-app-to-db | Allow | `10.0.2.4` | `10.0.3.4` | TCP 3306 |

Anything else between the subnets (for example SSH from frontend to DB) hits the firewall's default deny.

#### 🌐 Application rules (`rcg-application`, priority 300)
| Collection | Priority | Action | Target FQDNs |
|---|---|---|---|
| deny-youtube | 100 | **Deny** | `youtube.com`, `*.youtube.com`, `youtu.be`, `*.ytimg.com`, `*.googlevideo.com` |
| allow-google | 200 | **Allow** | `google.com`, `*.google.com`, `*.gstatic.com` |
| └ allow-ubuntu-updates | (same collection) | Allow | `*.ubuntu.com`, `archive.ubuntu.com`, `security.ubuntu.com`, `*.launchpad.net` |

Within a policy, rules are processed **DNAT → Network → Application**, and inside each type by priority (lower number first). That's why the YouTube **Deny** (100) is evaluated before the Google **Allow** (200). The Ubuntu rule exists so `apt install` works on the VMs. Without it the setup scripts would fail, which is itself a good demonstration of default deny.

### Step 3: Configure the VMs (`03-setup-vms.sh`)
Both VMs are reached **only** through the firewall DNAT SSH ports.

**MySQL VM:**
```bash
FW=$(az network public-ip show -g rg-azfw-demo -n pip-azfw-demo --query ipAddress -o tsv)
scp -P 2202 backend/setup-mysql.sh azureuser@$FW:/tmp/
ssh -p 2202 azureuser@$FW "sudo bash /tmp/setup-mysql.sh"
```
This installs MySQL 8, sets `bind-address = 0.0.0.0`, creates database `fwdemo`, creates user `appuser@'10.0.2.%'`, and seeds a `products` table.

**Frontend VM:**
```bash
scp -r -P 2201 frontend azureuser@$FW:/tmp/
ssh -p 2201 azureuser@$FW "sudo DB_HOST=10.0.3.4 bash /tmp/frontend/setup-frontend.sh"
```
This installs `python3-flask`, `python3-pymysql` and `gunicorn` from the Ubuntu repos, copies the app to `/opt/fwdemo`, writes DB settings to `/etc/fwdemo.env`, and starts the `fwdemo` systemd service on port 80.

> 🔐 Change the default DB password (`Demo@Pass123!`) by exporting `DB_PASS=...` for **both** setup scripts.

---

## 6. Use the demo UI

Open **`http://<FIREWALL_PUBLIC_IP>`** in your browser.

| Panel | What it shows |
|---|---|
| **Traffic path** | Browser → Firewall → vm-frontend → vm-mysql, with the DB link turning green or red based on a live check |
| **Stats** | Which VM served the page, the **client IP the app sees** (the firewall's private IP, because DNAT also SNATs), MySQL version and latency |
| **Application rules** | Click ▶ to have the frontend VM fetch Google ✅, YouTube ❌, Ubuntu archive ✅ and Bing ❌ (no rule, so default deny) |
| **Network rules** | Raw TCP connects from 10.0.2.4 to 10.0.3.4: port 3306 ✅, 22 ❌, 80 ❌ |
| **Inventory** | Add, search, change stock and delete products. Every action is a SQL query that crosses the network rule |

---

## 7. Verify from the command line

```bash
FW=<FIREWALL_PUBLIC_IP>

# DNAT: web app reachable from the internet
curl -I http://$FW

# SSH into the frontend through DNAT
ssh -p 2201 azureuser@$FW

# --- on vm-frontend ---
curl -sI https://www.google.com | head -1     # HTTP/2 200          -> ALLOWED (app rule)
curl -sI https://www.youtube.com              # reset / no response  -> DENIED  (app rule)
curl -s  http://www.youtube.com               # "Action: Deny. Reason: ..." from Azure Firewall
nc -zv 10.0.3.4 3306                          # succeeded            -> ALLOWED (network rule)
nc -zv -w 4 10.0.3.4 22                       # timed out            -> DENIED  (default deny)
```

### See the decisions in the logs (optional)
Turn on diagnostic settings for the firewall (Firewall → Diagnostic settings → send **Azure Firewall resource-specific logs** to a Log Analytics workspace), then query:

```kusto
// Application rule hits (Google allowed, YouTube denied)
AZFWApplicationRule
| where TimeGenerated > ago(30m)
| project TimeGenerated, SourceIp, Fqdn, Action, RuleCollection, Rule
| order by TimeGenerated desc

// Network rule hits (3306 allowed, everything else denied)
AZFWNetworkRule
| where TimeGenerated > ago(30m)
| project TimeGenerated, SourceIp, DestinationIp, DestinationPort, Action, Rule

// DNAT translations
AZFWNatRule
| where TimeGenerated > ago(30m)
| project TimeGenerated, SourceIp, DestinationPort, TranslatedIp, TranslatedPort
```

---

## 8. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Browser can't open `http://FW_IP` | Check the `fwdemo` service on the VM: `ssh -p 2201 ...` then `sudo systemctl status fwdemo` and `sudo journalctl -u fwdemo -n 50` |
| SSH via 2201/2202 times out | Your public IP changed. Re-run `02-firewall-rules.sh`, or edit the `ssh-to-*` rules' source to your new IP |
| `apt-get update` hangs on a VM | The `allow-ubuntu-updates` app rule is missing, or the route table isn't attached |
| UI shows "MySQL unreachable" | On vm-mysql: `sudo ss -ltnp \| grep 3306` should show `0.0.0.0:3306`. Check the network rule source/destination IPs and that `appuser@'10.0.2.%'` exists |
| Google test also shows blocked | The redirect went to another domain (for example `consent.google.com` is fine, but a regional `google.co.in` isn't). Add `google.co.in` / `*.google.co.in` to the allow rule |
| Rule changes don't apply | Policy updates take 1–3 minutes to propagate to the firewall |

---

## 9. Clean up

```bash
./scripts/99-cleanup.sh
# or
az group delete -n rg-azfw-demo --yes --no-wait
```

---

## 10. Ideas to extend
- Switch to **Firewall Premium** and enable **TLS inspection** and **URL filtering** (block specific paths, not just FQDNs).
- Use **Web Categories** (for example deny *Social networking*) instead of FQDN lists.
- Turn on **Threat Intelligence** in *Alert and deny* mode.
- Add **IP Groups** for the frontend and DB subnets to simplify rules.
- Add **Azure Bastion** and remove the SSH DNAT rules.
