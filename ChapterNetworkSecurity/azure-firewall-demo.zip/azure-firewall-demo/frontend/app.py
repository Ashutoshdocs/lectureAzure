"""
Azure Firewall Demo - Frontend (Flask)
Runs on vm-frontend (10.0.2.4:80), reached from the browser via the firewall DNAT rule.
Talks to MySQL on vm-mysql (10.0.3.4:3306) through the firewall network rule.
Also lets you test outbound internet (Google allowed / YouTube denied) from this VM.
"""
import os
import socket
import time
import urllib.request
import urllib.error
import ssl

import pymysql
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

DB = dict(
    host=os.getenv("DB_HOST", "10.0.3.4"),
    user=os.getenv("DB_USER", "appuser"),
    password=os.getenv("DB_PASS", "Demo@Pass123!"),
    database=os.getenv("DB_NAME", "fwdemo"),
    port=3306,
    connect_timeout=4,
    read_timeout=5,
    cursorclass=pymysql.cursors.DictCursor,
    autocommit=True,
)

# Only these targets can be tested, so the endpoint can't be abused as an open proxy.
EGRESS_TARGETS = {
    "google":  "https://www.google.com",
    "youtube": "https://www.youtube.com",
    "ubuntu":  "http://archive.ubuntu.com/ubuntu/",
    "bing":    "https://www.bing.com",  # not in any allow rule -> default deny
}
TCP_TARGETS = {"mysql": 3306, "ssh": 22, "http": 80}


def db():
    return pymysql.connect(**DB)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    info = {
        "frontend_host": socket.gethostname(),
        "frontend_ip": _local_ip(),
        "client_ip_seen": request.remote_addr,  # shows the firewall's SNAT address
        "db_host": DB["host"],
    }
    t0 = time.time()
    try:
        with db() as conn, conn.cursor() as cur:
            cur.execute("SELECT VERSION() AS v, @@hostname AS h")
            row = cur.fetchone()
        info.update(db_ok=True, db_version=row["v"], db_hostname=row["h"],
                    db_latency_ms=round((time.time() - t0) * 1000, 1))
    except Exception as e:  # noqa: BLE001
        info.update(db_ok=False, db_error=str(e),
                    db_latency_ms=round((time.time() - t0) * 1000, 1))
    return jsonify(info)


# ------------------------- Products CRUD -------------------------
@app.get("/api/products")
def list_products():
    try:
        with db() as conn, conn.cursor() as cur:
            cur.execute("SELECT id,name,category,price,stock,created_at FROM products ORDER BY id DESC")
            rows = cur.fetchall()
        for r in rows:
            r["price"] = float(r["price"])
            r["created_at"] = r["created_at"].isoformat() if r["created_at"] else None
        return jsonify(rows)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 503


@app.post("/api/products")
def add_product():
    d = request.get_json(force=True)
    try:
        name = str(d["name"]).strip()[:100]
        category = str(d.get("category", "General")).strip()[:50] or "General"
        price = float(d["price"])
        stock = int(d.get("stock", 0))
        if not name:
            raise ValueError("name required")
    except (KeyError, ValueError, TypeError) as e:
        return jsonify(error=f"Invalid input: {e}"), 400
    try:
        with db() as conn, conn.cursor() as cur:
            cur.execute("INSERT INTO products (name,category,price,stock) VALUES (%s,%s,%s,%s)",
                        (name, category, price, stock))
            new_id = cur.lastrowid
        return jsonify(id=new_id), 201
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 503


@app.patch("/api/products/<int:pid>/stock")
def change_stock(pid):
    delta = int(request.get_json(force=True).get("delta", 0))
    try:
        with db() as conn, conn.cursor() as cur:
            cur.execute("UPDATE products SET stock = GREATEST(stock + %s, 0) WHERE id=%s", (delta, pid))
        return jsonify(ok=True)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 503


@app.delete("/api/products/<int:pid>")
def delete_product(pid):
    try:
        with db() as conn, conn.cursor() as cur:
            cur.execute("DELETE FROM products WHERE id=%s", (pid,))
        return jsonify(ok=True)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 503


# ------------------------- Firewall tests -------------------------
@app.get("/api/egress/<target>")
def egress(target):
    url = EGRESS_TARGETS.get(target)
    if not url:
        return jsonify(error="unknown target"), 400
    t0 = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "azfw-demo/1.0"})
        with urllib.request.urlopen(req, timeout=6, context=ssl.create_default_context()) as r:
            code = r.status
        return jsonify(target=target, url=url, allowed=True, status=code,
                       ms=round((time.time() - t0) * 1000))
    except urllib.error.HTTPError as e:
        # Azure Firewall answers denied plain-HTTP requests with a 470 and a deny message.
        body = e.read(300).decode(errors="ignore")
        blocked = e.code == 470 or "Azure Firewall" in body
        return jsonify(target=target, url=url, allowed=not blocked, status=e.code,
                       detail=body.strip()[:200], ms=round((time.time() - t0) * 1000))
    except Exception as e:  # noqa: BLE001  (HTTPS denials show up as a reset / timeout)
        return jsonify(target=target, url=url, allowed=False, status=None,
                       detail=f"{type(e).__name__}: {e}"[:200], ms=round((time.time() - t0) * 1000))


@app.get("/api/tcp/<name>")
def tcp(name):
    port = TCP_TARGETS.get(name)
    if not port:
        return jsonify(error="unknown target"), 400
    t0 = time.time()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(4)
    try:
        s.connect((DB["host"], port))
        ok, detail = True, "TCP handshake completed"
    except Exception as e:  # noqa: BLE001
        ok, detail = False, f"{type(e).__name__}: {e}"
    finally:
        s.close()
    return jsonify(host=DB["host"], port=port, allowed=ok, detail=detail,
                   ms=round((time.time() - t0) * 1000))


def _local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((DB["host"], 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:  # noqa: BLE001
        return "unknown"


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "80")), debug=False)
