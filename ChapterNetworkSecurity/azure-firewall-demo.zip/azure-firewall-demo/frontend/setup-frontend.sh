#!/usr/bin/env bash
# Run on the frontend VM (10.0.2.4) from inside the copied "frontend" folder's parent or anywhere:
#   sudo DB_HOST=10.0.3.4 bash setup-frontend.sh
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="/opt/fwdemo"

DB_HOST="${DB_HOST:-10.0.3.4}"
DB_NAME="${DB_NAME:-fwdemo}"
DB_USER="${DB_USER:-appuser}"
DB_PASS="${DB_PASS:-Demo@Pass123!}"

export DEBIAN_FRONTEND=noninteractive
echo ">>> Installing Python packages from Ubuntu repos (allowed by firewall app rule)"
apt-get update -y
apt-get install -y python3-flask python3-pymysql gunicorn

echo ">>> Copying app to $APP_DIR"
mkdir -p "$APP_DIR/templates"
cp "$SRC/app.py" "$APP_DIR/"
cp "$SRC/templates/index.html" "$APP_DIR/templates/"

cat > /etc/fwdemo.env <<EOF
DB_HOST=$DB_HOST
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASS=$DB_PASS
EOF
chmod 600 /etc/fwdemo.env

cp "$SRC/fwdemo.service" /etc/systemd/system/fwdemo.service
systemctl daemon-reload
systemctl enable --now fwdemo
systemctl restart fwdemo
sleep 2
systemctl --no-pager status fwdemo | head -n 5
echo ""
echo "Frontend running on :80  ->  open http://<FIREWALL_PUBLIC_IP>"
